jQuery('.featured-section .title-wrap').matchHeight({ 
	property: 'min-height' 
});